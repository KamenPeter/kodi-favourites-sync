"""Called when user clicks 'Validate endpoint' button in settings"""
import xbmcgui
try:
    from sync import validate_endpoint
except ImportError:
    from .sync import validate_endpoint

def main():
    dialog = xbmcgui.Dialog()
    result = validate_endpoint()
    if result.get("ok"):
        dialog.notification("Favourites Sync", "Endpoint validated successfully!", xbmcgui.NOTIFICATION_INFO, 3000)
    else:
        dialog.ok("Validation Failed", f"Error: {result.get('error', 'Unknown error')}")

if __name__ == "__main__":
    main()
